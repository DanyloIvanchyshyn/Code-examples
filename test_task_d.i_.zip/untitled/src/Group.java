import java.util.ArrayList;

public class Group {
    ArrayList arrayList;

    public Group(ArrayList arrayList) {
        this.arrayList = arrayList;
    }

    public ArrayList createNewGroup () {
        ArrayList<Student> new_group = new ArrayList<>();
        return new_group;
    }

    @Override
    public String toString() {
        return "Group{" +
                "arrayList=" + arrayList +
                '}';
    }
}

