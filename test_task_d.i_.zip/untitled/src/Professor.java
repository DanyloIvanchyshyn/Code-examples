public class Professor {
    String name;
    boolean can_kick_out_students;
    int exp;
    boolean choose_class_monitor;

    public Professor(String name, boolean can_kick_out_students, int exp, boolean choose_class_monitor) {
        this.name = name;
        this.can_kick_out_students = can_kick_out_students;
        this.exp = exp;
        this.choose_class_monitor = choose_class_monitor;
    }

    @Override
    public String toString() {
        return "Professor{" +
                "name='" + name + '\'' +
                ", can_kick_out_students=" + can_kick_out_students +
                ", exp=" + exp +
                ", choose_class_monitor=" + choose_class_monitor +
                '}';
    }

}
