public class Student {
    String name;
    byte exp;
    byte honesty;
    boolean already_was_class_monitor;
    byte leadskills;
    byte laziness;
    boolean presence;

    public Student (String name, byte exp, byte honesty, boolean already_was_class_monitor, byte leadskills, byte laziness, boolean presence) {
        this.name = name;
        this.exp = exp;
        this.honesty = honesty;
        this.already_was_class_monitor = already_was_class_monitor;
        this.leadskills = leadskills;
        this.laziness = laziness;
        this.presence = presence;
    }

    public int getExp(){
        return exp;
    }

    public byte getHonesty() {
        return honesty;
    }

    public byte getLeadskills() {
        return leadskills;
    }

    public byte getLaziness() {
        return laziness;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", exp=" + exp +
                ", honesty=" + honesty +
                ", already_was_class_monitor=" + already_was_class_monitor +
                ", leadskills=" + leadskills +
                ", laziness=" + laziness +
                ", presence=" + presence +
                '}';
    }
}

