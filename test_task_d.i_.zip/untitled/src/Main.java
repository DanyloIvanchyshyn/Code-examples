import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Random random = new Random();
        Student student1 = new Student("Susan", (byte) 4, (byte) 7, true, (byte) 7, (byte) 4, random.nextBoolean());
        Student student2 = new Student("Tim", (byte) 4, (byte) 3, false, (byte) 6, (byte) 3, random.nextBoolean());
        Student student3 = new Student("Ugo", (byte) 6, (byte) 9, true, (byte) 4, (byte) 2, random.nextBoolean());
        Student student4 = new Student("Maria", (byte) 1, (byte) 5, false, (byte) 5, (byte) 9, random.nextBoolean());
        Student student5 = new Student("Olya", (byte) 2, (byte) 7, false, (byte) 7, (byte) 8, random.nextBoolean());
        Student student6 = new Student("Max", (byte) 3, (byte) 3, true, (byte) 2, (byte) 1, random.nextBoolean());
        Student student7 = new Student("Bella", (byte) 9, (byte) 4, false, (byte) 3, (byte) 5, random.nextBoolean());
        Student student8 = new Student("Mark", (byte) 9, (byte) 2, false, (byte) 7, (byte) 8, random.nextBoolean());
        Student student9 = new Student("Hloe", (byte) 1, (byte) 5, true, (byte) 6, (byte) 9, random.nextBoolean());
        Student student10 = new Student("Ben", (byte) 4, (byte) 2, false, (byte) 5, (byte) 3, random.nextBoolean());

        ArrayList<Student> list = new ArrayList<>();
        list.add(student1);
        list.add(student2);
        list.add(student3);
        list.add(student4);
        list.add(student5);
        list.add(student6);
        list.add(student7);
        list.add(student8);
        list.add(student9);
        list.add(student10);

        Professor Leontovych = new Professor("Leontovych", true, 5, true);
        Professor Lysenko = new Professor("Lysenko", false, 3, false);
        final String s = "Leontovych";
        final String w = "Lysenko";
        final String r = "qwerty5678";

        Scanner scan = new Scanner(System.in);
        System.out.println(ConsoleColors.YELLOW_BACKGROUND_BRIGHT);
        System.out.println("Hello, mr Professor !\n Please, log in Your account.\n Enter Your surname:\n ");
        String y = scan.nextLine();
        if (y.matches(s) || y.matches(w)) {
            System.out.println("\nNow enter Your password:\n");
        } else {
            System.out.println("\nI am sorry, but I cannot recognize You.\n Please, check if You have done everything correct or try again later...");
            return;
        }
        String p = scan.nextLine();
        if (p.matches(r)) {
            System.out.println(ConsoleColors.GREEN_UNDERLINED);
            System.out.print("\nAccess granted !\n\n");
            System.out.println(ConsoleColors.BLACK);
            System.out.println(ConsoleColors.YELLOW_BACKGROUND_BRIGHT);
            System.out.println("What would You like to do, mr " + y + " ?\n");
            System.out.println(ConsoleColors.RED);
            System.out.println("1.Start a call-over\n2.Kick out a student\n3.Create a new group of students\n4.Choose a class monitor\n");

            int t = scan.nextInt();
            int counter1 = 0;
            int counter2 = 0;

            if (t == 1) {
                System.out.println("\nStarting a call-over...\n");
                for (int j = 0; j < list.size(); j++) {
                    System.out.println(ConsoleColors.BLACK_BOLD);
                    System.out.print(j + 1 + ". Is " + list.get(j).name + " present ?\t");
                    if (list.get(j).presence) {
                        counter1++;
                        System.out.print(ConsoleColors.GREEN);
                        System.out.println("Yes, " + list.get(j).name + " is present.\n");
                    } else {
                        counter2++;
                        System.out.print(ConsoleColors.BLUE_BOLD_BRIGHT);
                        System.out.println("No, " + list.get(j).name + " is not present.\n\n");
                    }
                }
                System.out.println(ConsoleColors.YELLOW);
                System.out.println(counter1 + " students are present and " + counter2 + " are absent.\n");
            } else if (t == 2) {
                System.out.println(ConsoleColors.YELLOW_BACKGROUND_BRIGHT);
                System.out.println("Let me check if You have a permission for kicking out students...");
                if (Lysenko.can_kick_out_students || Leontovych.can_kick_out_students) {
                    System.out.println("\nType a number of a student You want to kick out:\n");
                    int e = scan.nextByte();
                    for (int j = 0; j < list.size(); j++) {
                        if (j == e - 1) {
                            list.remove(j);
                        }
                    }
                    System.out.println(ConsoleColors.CYAN_BACKGROUND_BRIGHT);
                    System.out.println("Student number " + e + " has been kicked out from the school.\n\nHere is a new list of students:\n");
                    for (Student pp : list)
                        System.out.println(pp);
                    return;
                } else {
                    System.out.println(ConsoleColors.RED);
                    System.out.println("I'm sorry, but it seems You aren't allowed to do that !\nTry again later...");
                    return;
                }
            } else if (t == 3) {
                System.out.println(ConsoleColors.YELLOW_BACKGROUND_BRIGHT);
                System.out.println("New group is creating...\n");
                Group groupx = new Group(list);
                ArrayList<Student> arrayList = groupx.createNewGroup();
                System.out.println("Group have been created.\n");
                return;
            }
            else{
                System.out.println(ConsoleColors.YELLOW_BACKGROUND_BRIGHT);
                System.out.println("Checking for Your a class monitor choosing permission...\n");
                if (Leontovych.choose_class_monitor || Lysenko.choose_class_monitor) {
                    System.out.println(ConsoleColors.YELLOW_BACKGROUND_BRIGHT);
                    System.out.println("Here we go ! Enter parameters You want class monitor to have:\n");

                    System.out.println("Class monitors experience must be at least: ");
                    int i = scan.nextInt();
                    System.out.println("\nClass monitors honesty must be at least: ");
                    int k = scan.nextInt();
                    System.out.println("\nClass monitors leadskills must be at least: ");
                    int m = scan.nextInt();
                    System.out.println("\nClass monitors laziness must be less then: ");
                    int n = scan.nextInt();

                    boolean flag = false;
                    ArrayList<Student> list2 = new ArrayList<>();
                    int counter3 = 0;
                    int win = 0;

                    for (int j = 0; j < list.size(); j++) {
                        if (list.get(j).already_was_class_monitor)
                            continue;
                        if (list.get(j).exp >= i && list.get(j).honesty >= k && list.get(j).leadskills >= m && list.get(j).laziness <= n) {
                            list2.add(list.get(j));
                            win = j;
                            list.get(j).already_was_class_monitor = true;
                            flag = true;
                            counter3++;
                        }
                        if (!flag) {
                            System.out.println("\nThere are no students matching Your criterias to become a class monitor. Try again later...");
                            return;
                        }
                    }
                    if (counter3>1){
                        System.out.println("\nIt seems there are a lot of candidats to become a class monitor.\n\n");
                        System.out.println(ConsoleColors.BLUE_BOLD_BRIGHT);
                        System.out.println(ConsoleColors.YELLOW_BACKGROUND_BRIGHT);
                        System.out.println("They are:\n");
                        for (Student ppp : list)
                            System.out.println(ppp);
                        System.out.println("\nLet's head for the second tour !\n\nInput new class monotors criterias, but be more strict:\n");
                    } else {
                        System.out.println(ConsoleColors.BLUE_BOLD_BRIGHT);
                        System.out.println("\nStudents chose " + list2.get(win).name + " to be a class monitor !\n\nHere are some details: " + list.get(win));
                    }
                    flag = false;
                    System.out.println("Class monitors experience must be at least: ");
                    int ii = scan.nextInt();
                    System.out.println("\nClass monitors honesty must be at least: ");
                    int kk = scan.nextInt();
                    System.out.println("\nClass monitors leadskills must be at least: ");
                    int mm = scan.nextInt();
                    System.out.println("\nClass monitors laziness must be less then: ");
                    int nn = scan.nextInt();
                    for (int d = 0; d < list2.size(); d++) {
                        if (list.get(d).exp >= ii && list.get(d).honesty >= kk && list.get(d).leadskills >= mm && list.get(d).laziness <= nn) {
                            System.out.println(ConsoleColors.BLUE_BOLD_BRIGHT);
                            System.out.println("\nStudents chose " + list2.get(d).name + " to be a class monitor !\n\nHere are some details: " + list.get(d));
                            flag=true;
                        } if (!flag){
                            System.out.println("\nThere are no students matching Your criterias to become a class monitor. Try again later...");
                            return;
                        }
                    }
                } else {
                    System.out.println(ConsoleColors.RED);
                    System.out.println("Sorry, but You can't do that. Contact system admin...");
                    return;
                }
            }
        }   else {
            System.out.println("\nIncorrect password ! Try again later...");
            return;
        }
    }
}


